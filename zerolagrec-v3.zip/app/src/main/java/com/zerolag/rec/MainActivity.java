package com.zerolag.rec;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.DocumentsContract;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {

    private static final int REQ_CAPTURE = 1001;
    private static final int REQ_FOLDER = 1002;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private Button button;
    private TextView status;
    private TextView folderText;

    private final Runnable refresh = new Runnable() {
        @Override
        public void run() {
            updateUi();
            handler.postDelayed(this, 500);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        float d = getResources().getDisplayMetrics().density;
        int pad = (int) (24 * d);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("ZeroLag Rec");
        title.setTextSize(28);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView info = new TextView(this);
        info.setText("1280x576 | 30 FPS | 4 Mbps CBR | Landscape");
        info.setTextSize(14);
        info.setGravity(Gravity.CENTER);
        info.setPadding(0, (int) (8 * d), 0, (int) (24 * d));
        root.addView(info);

        folderText = new TextView(this);
        folderText.setTextSize(15);
        folderText.setGravity(Gravity.CENTER);
        folderText.setPadding(0, 0, 0, (int) (8 * d));
        root.addView(folderText);

        Button folderBtn = new Button(this);
        folderBtn.setText("SAVE LOCATION CHUNO");
        folderBtn.setOnClickListener(v -> pickFolder());
        LinearLayout.LayoutParams flp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                (int) (56 * d));
        flp.bottomMargin = (int) (24 * d);
        root.addView(folderBtn, flp);

        status = new TextView(this);
        status.setTextSize(16);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, 0, 0, (int) (24 * d));
        root.addView(status);

        button = new Button(this);
        button.setTextSize(20);
        button.setOnClickListener(v -> onButtonClick());
        root.addView(button, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                (int) (72 * d)));

        setContentView(root);
        updateFolderText();
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(refresh);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(refresh);
    }

    private void pickFolder() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, REQ_FOLDER);
    }

    private void updateFolderText() {
        String s = getSharedPreferences("zlr", MODE_PRIVATE).getString("tree", null);
        if (s == null) {
            folderText.setText("Save: Internal (Movies/ZeroLagRec)\nSD card ke liye neeche button dabao");
            return;
        }
        try {
            String id = DocumentsContract.getTreeDocumentId(Uri.parse(s));
            int i = id.indexOf(':');
            String vol = id.substring(0, i);
            String rest = id.substring(i + 1);
            folderText.setText("Save: " + (vol.equals("primary") ? "Internal/" : "SD card/") + rest);
        } catch (Exception e) {
            folderText.setText("Save: chuna hua folder");
        }
    }

    private void onButtonClick() {
        if (RecorderService.isRecording) {
            Intent stop = new Intent(this, RecorderService.class);
            stop.setAction(RecorderService.ACTION_STOP);
            startService(stop);
        } else if (!RecorderService.busy) {
            MediaProjectionManager mpm =
                    (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_FOLDER) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                Uri tree = data.getData();
                try {
                    getContentResolver().takePersistableUriPermission(tree,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION
                                    | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    getSharedPreferences("zlr", MODE_PRIVATE)
                            .edit().putString("tree", tree.toString()).apply();
                } catch (Exception e) {
                    RecorderService.lastMessage = "Folder save nahi hua: " + e.getMessage();
                }
                updateFolderText();
            }
            return;
        }

        if (requestCode == REQ_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                Intent start = new Intent(this, RecorderService.class);
                start.setAction(RecorderService.ACTION_START);
                start.putExtra("code", resultCode);
                start.putExtra("data", data);
                startForegroundService(start);
            } else {
                RecorderService.lastMessage = "Permission nahi mili";
            }
        }
    }

    private void updateUi() {
        boolean rec = RecorderService.isRecording;
        button.setText(rec ? "STOP" : "START RECORDING");
        button.setEnabled(rec || !RecorderService.busy);
        String m = RecorderService.lastMessage;
        status.setText(m == null || m.isEmpty() ? "Ready" : m);
    }
}
