package com.zerolag.rec;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;

/** Transparent activity: sirf screen-capture permission popup dikhata hai, phir band ho jata hai. */
public class CaptureActivity extends Activity {

    private static final int REQ = 2001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (savedInstanceState == null) {
            MediaProjectionManager mpm =
                    (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            startActivityForResult(mpm.createScreenCaptureIntent(), REQ);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ) {
            if (resultCode == RESULT_OK && data != null) {
                Intent start = new Intent(this, RecorderService.class);
                start.setAction(RecorderService.ACTION_START);
                start.putExtra("code", resultCode);
                start.putExtra("data", data);
                startForegroundService(start);
            } else {
                RecorderService.lastMessage = "Permission nahi mili";
            }
        }
        finish();
    }
}
