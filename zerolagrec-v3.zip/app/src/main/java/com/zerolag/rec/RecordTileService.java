package com.zerolag.rec;

import android.content.Intent;
import android.graphics.drawable.Icon;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

/** Notification panel (Quick Settings) ka ZeroLag Rec button. */
public class RecordTileService extends TileService {

    @Override
    public void onStartListening() {
        super.onStartListening();
        refresh();
    }

    @Override
    public void onClick() {
        super.onClick();
        if (RecorderService.isRecording) {
            Intent stop = new Intent(this, RecorderService.class);
            stop.setAction(RecorderService.ACTION_STOP);
            startService(stop);
            render(Tile.STATE_INACTIVE, "Saving...");
        } else if (!RecorderService.busy) {
            Intent i = new Intent(this, CaptureActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivityAndCollapse(i);
        }
    }

    private void refresh() {
        if (RecorderService.isRecording) {
            render(Tile.STATE_ACTIVE, "Recording - tap to STOP");
        } else if (RecorderService.busy) {
            render(Tile.STATE_INACTIVE, "Saving...");
        } else {
            render(Tile.STATE_INACTIVE, "Tap to record");
        }
    }

    private void render(int state, String subtitle) {
        Tile tile = getQsTile();
        if (tile == null) return;
        tile.setState(state);
        tile.setLabel("ZeroLag Rec");
        tile.setSubtitle(subtitle);
        tile.setIcon(Icon.createWithResource(this, android.R.drawable.ic_media_play));
        tile.updateTile();
    }
}
