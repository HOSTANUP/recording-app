package com.zerolag.rec;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.drawable.Icon;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.media.MediaScannerConnection;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.Surface;
import android.widget.Toast;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class RecorderService extends Service {

    public static final String ACTION_START = "com.zerolag.rec.START";
    public static final String ACTION_STOP = "com.zerolag.rec.STOP";

    public static volatile boolean isRecording = false;
    public static volatile boolean busy = false;
    public static volatile String lastMessage = "";

    private static final String TAG = "ZeroLagRec";
    private static final String CHANNEL_ID = "zerolag_rec";

    // Stage 1: fixed settings
    private static final int LONG_SIDE = 1280;
    private static final int BITRATE = 4_000_000;
    private static final int FPS = 30;

    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private MediaCodec encoder;
    private Surface inputSurface;
    private MediaMuxer muxer;
    private ParcelFileDescriptor pfd;
    private Uri outUri;
    private String displayName = "";
    private boolean docMode = false;
    private String fallbackNote = "";
    private Thread drainThread;
    private volatile boolean stopping = false;
    private volatile long stopTime = 0;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) {
            stopSelf();
            return START_NOT_STICKY;
        }
        String action = intent.getAction();

        if (ACTION_STOP.equals(action)) {
            if (isRecording) {
                stopRecording();
            } else if (!busy) {
                stopSelf();
            }
            return START_NOT_STICKY;
        }

        if (ACTION_START.equals(action)) {
            startForeground(1, buildNotification());
            if (busy) return START_NOT_STICKY;
            busy = true;
            int code = intent.getIntExtra("code", 0);
            Intent data = intent.getParcelableExtra("data");
            try {
                startRecording(code, data);
            } catch (Exception e) {
                Log.e(TAG, "start failed", e);
                lastMessage = "Error: " + e.getMessage();
                finishFile(false, 0);
            }
        }
        return START_NOT_STICKY;
    }

    private void startRecording(int code, Intent data) throws Exception {
        // Screen size -> always landscape video (game landscape me chalta hai)
        DisplayManager dmgr = getSystemService(DisplayManager.class);
        Display display = dmgr.getDisplay(Display.DEFAULT_DISPLAY);
        DisplayMetrics dm = new DisplayMetrics();
        display.getRealMetrics(dm);
        int longSide = Math.max(dm.widthPixels, dm.heightPixels);
        int shortSide = Math.min(dm.widthPixels, dm.heightPixels);
        int w = LONG_SIDE;
        int h = Math.round(shortSide * (float) LONG_SIDE / longSide / 16f) * 16;

        // Output file: pehle chuna hua folder (SD card), warna internal Movies/ZeroLagRec
        displayName = "ZLR_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".mp4";
        docMode = false;
        fallbackNote = "";
        String treeStr = getSharedPreferences("zlr", MODE_PRIVATE).getString("tree", null);
        if (treeStr != null) {
            try {
                Uri tree = Uri.parse(treeStr);
                Uri parent = DocumentsContract.buildDocumentUriUsingTree(
                        tree, DocumentsContract.getTreeDocumentId(tree));
                outUri = DocumentsContract.createDocument(
                        getContentResolver(), parent, "video/mp4", displayName);
                if (outUri != null) {
                    pfd = getContentResolver().openFileDescriptor(outUri, "rw");
                    if (pfd != null) docMode = true;
                }
            } catch (Exception e) {
                Log.w(TAG, "Chuna hua folder open nahi hua", e);
            }
            if (!docMode) {
                try {
                    if (outUri != null) DocumentsContract.deleteDocument(getContentResolver(), outUri);
                } catch (Exception ignored) {
                }
                outUri = null;
                pfd = null;
                fallbackNote = " (chuna hua folder nahi mila, isliye internal me save hui)";
            }
        }
        if (!docMode) {
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.Video.Media.DISPLAY_NAME, displayName);
            cv.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
            cv.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ZeroLagRec");
            cv.put(MediaStore.Video.Media.IS_PENDING, 1);
            outUri = getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv);
            if (outUri == null) throw new IOException("File nahi ban payi");
            pfd = getContentResolver().openFileDescriptor(outUri, "rw");
            if (pfd == null) throw new IOException("File open nahi hui");
        }
        muxer = new MediaMuxer(pfd.getFileDescriptor(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);

        // Encoder: screen seedha encoder ke surface pe
        encoder = createEncoder(w, h);
        inputSurface = encoder.createInputSurface();
        encoder.start();

        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        projection = mpm.getMediaProjection(code, data);
        projection.registerCallback(new MediaProjection.Callback() {
            @Override
            public void onStop() {
                stopRecording();
            }
        }, new Handler(Looper.getMainLooper()));

        virtualDisplay = projection.createVirtualDisplay("ZeroLagRec", w, h, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, inputSurface, null, null);

        stopping = false;
        isRecording = true;
        lastMessage = "Recording chal rahi hai (" + w + "x" + h + ")\nHome dabao, game kholo. Rokne ke liye notification me STOP.";
        drainThread = new Thread(this::drainLoop, "zlr-drain");
        drainThread.start();
    }

    private MediaCodec createEncoder(int w, int h) throws IOException {
        Exception last = null;
        for (int attempt = 0; attempt < 3; attempt++) {
            MediaCodec codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
            try {
                MediaFormat f = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h);
                f.setInteger(MediaFormat.KEY_COLOR_FORMAT,
                        MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
                f.setInteger(MediaFormat.KEY_BIT_RATE, BITRATE);
                f.setInteger(MediaFormat.KEY_FRAME_RATE, FPS);
                f.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2);
                if (attempt <= 1) {
                    f.setInteger(MediaFormat.KEY_PRIORITY, 0);
                    f.setFloat("max-fps-to-encoder", FPS);
                    f.setInteger(MediaFormat.KEY_BITRATE_MODE,
                            MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_CBR);
                }
                if (attempt == 0) {
                    f.setInteger(MediaFormat.KEY_PROFILE,
                            MediaCodecInfo.CodecProfileLevel.AVCProfileHigh);
                }
                codec.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
                Log.i(TAG, "Encoder configured, attempt " + attempt);
                return codec;
            } catch (Exception e) {
                last = e;
                Log.w(TAG, "Encoder attempt " + attempt + " failed", e);
                codec.release();
            }
        }
        throw new IOException("Encoder start nahi hua: " + last);
    }

    private void stopRecording() {
        if (stopping) return;
        stopTime = System.currentTimeMillis();
        stopping = true;
        isRecording = false;
        lastMessage = "Save ho rahi hai...";
        try {
            if (virtualDisplay != null) virtualDisplay.release();
        } catch (Exception ignored) {
        }
        try {
            if (projection != null) projection.stop();
        } catch (Exception ignored) {
        }
        try {
            if (encoder != null) encoder.signalEndOfInputStream();
        } catch (Exception e) {
            Log.w(TAG, "signalEndOfInputStream failed", e);
        }
    }

    private void drainLoop() {
        MediaCodec enc = encoder;
        MediaMuxer mux = muxer;
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        int track = -1;
        boolean muxerStarted = false;
        long firstPts = -1;
        long samples = 0;
        try {
            while (true) {
                if (stopping && System.currentTimeMillis() - stopTime > 3000) break;
                int idx = enc.dequeueOutputBuffer(info, 10000);
                if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    track = mux.addTrack(enc.getOutputFormat());
                    mux.start();
                    muxerStarted = true;
                } else if (idx >= 0) {
                    ByteBuffer buf = enc.getOutputBuffer(idx);
                    if ((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                        info.size = 0;
                    }
                    if (info.size > 0 && muxerStarted && buf != null) {
                        buf.position(info.offset);
                        buf.limit(info.offset + info.size);
                        if (firstPts < 0) firstPts = info.presentationTimeUs;
                        info.presentationTimeUs -= firstPts;
                        mux.writeSampleData(track, buf, info);
                        samples++;
                    }
                    enc.releaseOutputBuffer(idx, false);
                    if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break;
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "drain error", e);
            lastMessage = "Error: " + e.getMessage();
        }
        finishFile(muxerStarted, samples);
    }

    private void finishFile(boolean muxerStarted, long samples) {
        isRecording = false;
        stopping = true;
        try {
            if (virtualDisplay != null) virtualDisplay.release();
        } catch (Exception ignored) {
        }
        try {
            if (projection != null) projection.stop();
        } catch (Exception ignored) {
        }
        try {
            if (encoder != null) encoder.stop();
        } catch (Exception ignored) {
        }
        try {
            if (encoder != null) encoder.release();
        } catch (Exception ignored) {
        }
        try {
            if (inputSurface != null) inputSurface.release();
        } catch (Exception ignored) {
        }

        boolean ok = false;
        try {
            if (muxer != null && muxerStarted) {
                muxer.stop();
                ok = samples > 0;
            }
        } catch (Exception e) {
            Log.w(TAG, "muxer stop failed", e);
        }
        try {
            if (muxer != null) muxer.release();
        } catch (Exception ignored) {
        }
        try {
            if (pfd != null) pfd.close();
        } catch (Exception ignored) {
        }

        if (outUri != null) {
            try {
                if (docMode) {
                    if (!ok) DocumentsContract.deleteDocument(getContentResolver(), outUri);
                } else if (ok) {
                    ContentValues cv = new ContentValues();
                    cv.put(MediaStore.Video.Media.IS_PENDING, 0);
                    getContentResolver().update(outUri, cv, null, null);
                } else {
                    getContentResolver().delete(outUri, null, null);
                }
            } catch (Exception e) {
                Log.w(TAG, "file finalize failed", e);
            }
        }
        if (ok && docMode) scanDoc(outUri);

        String msg = lastMessage == null ? "" : lastMessage;
        if (ok) {
            String where = docMode ? describeDoc(outUri) : "Movies/ZeroLagRec/" + displayName;
            lastMessage = "Saved: " + where + fallbackNote;
        } else if (!msg.startsWith("Error")) {
            lastMessage = "Video nahi bani (recording bahut chhoti thi?)";
        }

        new Handler(Looper.getMainLooper()).post(() -> {
            busy = false;
            try {
                Toast.makeText(getApplicationContext(), lastMessage, Toast.LENGTH_LONG).show();
            } catch (Exception ignored) {
            }
            stopForeground(true);
            stopSelf();
        });
    }

    private String describeDoc(Uri doc) {
        try {
            String id = DocumentsContract.getDocumentId(doc);
            int i = id.indexOf(':');
            String vol = id.substring(0, i);
            String rest = id.substring(i + 1);
            return (vol.equals("primary") ? "Internal/" : "SD card/") + rest;
        } catch (Exception e) {
            return displayName;
        }
    }

    private void scanDoc(Uri doc) {
        try {
            String id = DocumentsContract.getDocumentId(doc);
            int i = id.indexOf(':');
            String vol = id.substring(0, i);
            String rest = id.substring(i + 1);
            String path = vol.equals("primary")
                    ? "/storage/emulated/0/" + rest
                    : "/storage/" + vol + "/" + rest;
            MediaScannerConnection.scanFile(this, new String[]{path}, new String[]{"video/mp4"}, null);
        } catch (Exception ignored) {
        }
    }

    private Notification buildNotification() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        NotificationChannel ch = new NotificationChannel(
                CHANNEL_ID, "Recording", NotificationManager.IMPORTANCE_LOW);
        nm.createNotificationChannel(ch);

        Intent stopIntent = new Intent(this, RecorderService.class).setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 0, stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Action stopAction = new Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_media_pause),
                "STOP", stopPi).build();

        return new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_tile)
                .setContentTitle("ZeroLag Rec")
                .setContentText("Recording... STOP dabao to save ho jayegi")
                .setOngoing(true)
                .addAction(stopAction)
                .build();
    }
}
