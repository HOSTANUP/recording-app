package com.zerolag.rec;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.DocumentsContract;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Settings screen: tile ko long-press karne pe khulti hai. Yahan se save location badalte hain. */
public class MainActivity extends Activity {

    private static final int REQ_FOLDER = 1002;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView folderText;
    private TextView status;

    private final Runnable refresh = new Runnable() {
        @Override
        public void run() {
            String m = RecorderService.lastMessage;
            status.setText(m == null || m.isEmpty() ? "Last recording: -" : "Last: " + m);
            handler.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        float d = getResources().getDisplayMetrics().density;
        int pad = (int) (24 * d);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("ZeroLag Rec - Settings");
        title.setTextSize(26);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView info = new TextView(this);
        info.setText("1280x576 | 30 FPS | 4 Mbps CBR | Landscape\nRecording on/off: notification panel ka ZeroLag Rec tile");
        info.setTextSize(14);
        info.setGravity(Gravity.CENTER);
        info.setPadding(0, (int) (8 * d), 0, (int) (24 * d));
        root.addView(info);

        folderText = new TextView(this);
        folderText.setTextSize(16);
        folderText.setGravity(Gravity.CENTER);
        folderText.setPadding(0, 0, 0, (int) (12 * d));
        root.addView(folderText);

        Button folderBtn = new Button(this);
        folderBtn.setText("SD CARD / FOLDER CHUNO");
        folderBtn.setOnClickListener(v -> pickFolder());
        LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, (int) (60 * d));
        lp1.bottomMargin = (int) (8 * d);
        root.addView(folderBtn, lp1);

        Button internalBtn = new Button(this);
        internalBtn.setText("INTERNAL STORAGE USE KARO");
        internalBtn.setOnClickListener(v -> {
            getSharedPreferences("zlr", MODE_PRIVATE).edit().remove("tree").apply();
            updateFolderText();
        });
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, (int) (60 * d));
        lp2.bottomMargin = (int) (24 * d);
        root.addView(internalBtn, lp2);

        Button cutBtn = new Button(this);
        cutBtn.setText("VIDEO CUT (POV banao)");
        cutBtn.setOnClickListener(v -> startActivity(new Intent(this, CutActivity.class)));
        LinearLayout.LayoutParams lp3 = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, (int) (60 * d));
        lp3.bottomMargin = (int) (24 * d);
        root.addView(cutBtn, lp3);

        status = new TextView(this);
        status.setTextSize(14);
        status.setGravity(Gravity.CENTER);
        root.addView(status);

        setContentView(root);
        updateFolderText();
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(refresh);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(refresh);
    }

    private void pickFolder() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, REQ_FOLDER);
    }

    private void updateFolderText() {
        String s = getSharedPreferences("zlr", MODE_PRIVATE).getString("tree", null);
        if (s == null) {
            folderText.setText("Save: Internal (Movies/ZeroLagRec)");
            return;
        }
        try {
            String id = DocumentsContract.getTreeDocumentId(Uri.parse(s));
            int i = id.indexOf(':');
            String vol = id.substring(0, i);
            String rest = id.substring(i + 1);
            folderText.setText("Save: " + (vol.equals("primary") ? "Internal/" : "SD card/") + rest);
        } catch (Exception e) {
            folderText.setText("Save: chuna hua folder");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FOLDER && resultCode == RESULT_OK
                && data != null && data.getData() != null) {
            Uri tree = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(tree,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                                | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                getSharedPreferences("zlr", MODE_PRIVATE)
                        .edit().putString("tree", tree.toString()).apply();
            } catch (Exception e) {
                RecorderService.lastMessage = "Folder save nahi hua: " + e.getMessage();
            }
            updateFolderText();
        }
    }
}
