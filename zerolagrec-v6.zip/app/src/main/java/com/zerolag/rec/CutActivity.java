package com.zerolag.rec;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.media.MediaPlayer;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import android.text.InputType;
import android.view.Gravity;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Video Cut (fast / lossless): SD card se video chuno, frame-by-frame START/END set karo,
 * cut hui video wapas SD card ke chune hue folder me banti hai. Phone storage use nahi hota.
 */
public class CutActivity extends Activity implements SurfaceHolder.Callback {

    private static final int REQ_VIDEO = 3001;

    private final Handler handler = new Handler(Looper.getMainLooper());

    private MediaPlayer mp;
    private boolean prepared = false;
    private boolean surfaceReady = false;
    private Uri srcUri;
    private long durationMs = 0;
    private long curMs = 0;
    private long startMs = -1;
    private long endMs = -1;

    private SurfaceView surface;
    private SeekBar seek;
    private TextView posText, startText, endText, status;
    private EditText gotoEdit;
    private Button playBtn, cutBtn;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (mp != null && prepared && mp.isPlaying()) {
                curMs = mp.getCurrentPosition();
                updatePos();
            }
            handler.postDelayed(this, 100);
        }
    };

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private Button mk(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(13);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(0, 0, 0, 0);
        b.setOnClickListener(l);
        return b;
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER);
        return r;
    }

    private void addW(LinearLayout row, Button b) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(48), 1f);
        lp.setMargins(dp(2), dp(2), dp(2), dp(2));
        row.addView(b, lp);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12), dp(12), dp(12), dp(12));
        sv.addView(root);

        TextView title = new TextView(this);
        title.setText("Video Cut (fast, quality same)");
        title.setTextSize(20);
        root.addView(title);

        TextView info = new TextView(this);
        info.setText("Cut hui video 0-1 sec START point se pehle se shuru hogi, kabhi baad me nahi. "
                + "Original video wahi rehti hai.");
        info.setTextSize(12);
        info.setPadding(0, dp(4), 0, dp(8));
        root.addView(info);

        Button pick = new Button(this);
        pick.setText("VIDEO CHUNO (SD card)");
        pick.setOnClickListener(v -> pickVideo());
        root.addView(pick, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(52)));

        surface = new SurfaceView(this);
        surface.getHolder().addCallback(this);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(200));
        slp.topMargin = dp(8);
        root.addView(surface, slp);

        posText = new TextView(this);
        posText.setTextSize(16);
        posText.setGravity(Gravity.CENTER);
        posText.setText("00:00.000 / 00:00.000");
        root.addView(posText);

        seek = new SeekBar(this);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int progress, boolean fromUser) {
                if (fromUser && prepared) seekToMs(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
            }
        });
        root.addView(seek);

        LinearLayout r1 = row();
        addW(r1, mk("-10s", v -> stepBy(-10000)));
        addW(r1, mk("-1s", v -> stepBy(-1000)));
        addW(r1, mk("-1 frame", v -> stepBy(-33)));
        addW(r1, mk("+1 frame", v -> stepBy(33)));
        addW(r1, mk("+1s", v -> stepBy(1000)));
        addW(r1, mk("+10s", v -> stepBy(10000)));
        root.addView(r1);

        playBtn = new Button(this);
        playBtn.setText("PLAY");
        playBtn.setOnClickListener(v -> togglePlay());
        root.addView(playBtn, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(52)));

        LinearLayout r2 = row();
        gotoEdit = new EditText(this);
        gotoEdit.setHint("time (mm:ss) jaise 12:50");
        gotoEdit.setInputType(InputType.TYPE_CLASS_TEXT);
        gotoEdit.setSingleLine(true);
        r2.addView(gotoEdit, new LinearLayout.LayoutParams(0, dp(52), 3f));
        addW(r2, mk("GO", v -> {
            long ms = parseTime(gotoEdit.getText().toString());
            if (ms < 0) {
                status.setText("Time galat hai. Aise likho: 12:50 ya 1:02:03");
            } else {
                stepBy(0);
                seekToMs(ms);
            }
        }));
        root.addView(r2);

        LinearLayout r3 = row();
        addW(r3, mk("START yahan", v -> {
            startMs = nowMs();
            startText.setText("START: " + fmt(startMs));
        }));
        addW(r3, mk("END yahan", v -> {
            endMs = nowMs();
            endText.setText("END: " + fmt(endMs));
        }));
        root.addView(r3);

        startText = new TextView(this);
        startText.setTextSize(15);
        startText.setText("START: set nahi hua");
        root.addView(startText);

        endText = new TextView(this);
        endText.setTextSize(15);
        endText.setText("END: set nahi hua (khali chhodo to video ke end tak)");
        root.addView(endText);

        cutBtn = new Button(this);
        cutBtn.setText("CUT (SD card me save)");
        cutBtn.setOnClickListener(v -> startCut());
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(60));
        clp.topMargin = dp(12);
        root.addView(cutBtn, clp);

        status = new TextView(this);
        status.setTextSize(14);
        status.setPadding(0, dp(8), 0, dp(24));
        root.addView(status);

        setContentView(sv);

        if (savedInstanceState == null) pickVideo();
    }

    // ---------- file pick ----------

    private void pickVideo() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("video/*");
        startActivityForResult(i, REQ_VIDEO);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_VIDEO) return;
        if (resultCode == RESULT_OK && data != null && data.getData() != null) {
            loadVideo(data.getData());
        } else if (srcUri == null) {
            status.setText("Video nahi chuni. Upar VIDEO CHUNO dabao.");
        }
    }

    private String nameOf(Uri uri) {
        try (Cursor c = getContentResolver().query(uri,
                new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Exception ignored) {
        }
        return "video";
    }

    // ---------- player ----------

    private void loadVideo(Uri uri) {
        releasePlayer();
        srcUri = uri;
        prepared = false;
        startMs = -1;
        endMs = -1;
        curMs = 0;
        durationMs = 0;
        startText.setText("START: set nahi hua");
        endText.setText("END: set nahi hua (khali chhodo to video ke end tak)");
        playBtn.setText("PLAY");
        status.setText("Video khul rahi hai: " + nameOf(uri));
        try {
            mp = new MediaPlayer();
            mp.setDataSource(this, uri);
            if (surfaceReady) mp.setDisplay(surface.getHolder());
            mp.setOnPreparedListener(p -> {
                prepared = true;
                durationMs = p.getDuration();
                seek.setMax((int) durationMs);
                resizeSurface(p.getVideoWidth(), p.getVideoHeight());
                if (surfaceReady) p.setDisplay(surface.getHolder());
                p.seekTo(0, MediaPlayer.SEEK_CLOSEST);
                updatePos();
                status.setText("Video ready: " + nameOf(srcUri));
            });
            mp.setOnCompletionListener(p -> {
                curMs = durationMs;
                playBtn.setText("PLAY");
                updatePos();
            });
            mp.setOnErrorListener((p, what, extra) -> {
                status.setText("Player error (" + what + "/" + extra + ")");
                return true;
            });
            mp.prepareAsync();
        } catch (Exception e) {
            status.setText("Video nahi khuli: " + e.getMessage());
        }
    }

    private void resizeSurface(int vw, int vh) {
        if (vw <= 0 || vh <= 0) return;
        int w = surface.getWidth();
        if (w <= 0) w = getResources().getDisplayMetrics().widthPixels - dp(24);
        LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) surface.getLayoutParams();
        lp.height = (int) ((long) w * vh / vw);
        surface.setLayoutParams(lp);
    }

    private void releasePlayer() {
        if (mp != null) {
            try {
                mp.release();
            } catch (Exception ignored) {
            }
            mp = null;
        }
        prepared = false;
    }

    private long nowMs() {
        return (mp != null && prepared && mp.isPlaying()) ? mp.getCurrentPosition() : curMs;
    }

    private void seekToMs(long ms) {
        if (mp == null || !prepared) return;
        if (ms < 0) ms = 0;
        if (ms > durationMs) ms = durationMs;
        curMs = ms;
        mp.seekTo((int) ms, MediaPlayer.SEEK_CLOSEST);
        updatePos();
    }

    private void stepBy(long deltaMs) {
        if (mp == null || !prepared) return;
        if (mp.isPlaying()) {
            mp.pause();
            curMs = mp.getCurrentPosition();
            playBtn.setText("PLAY");
        }
        if (deltaMs != 0) seekToMs(curMs + deltaMs);
    }

    private void togglePlay() {
        if (mp == null || !prepared) return;
        if (mp.isPlaying()) {
            mp.pause();
            curMs = mp.getCurrentPosition();
            playBtn.setText("PLAY");
        } else {
            mp.start();
            playBtn.setText("PAUSE");
        }
    }

    private void updatePos() {
        posText.setText(fmt(curMs) + " / " + fmt(durationMs));
        seek.setProgress((int) curMs);
    }

    private static String fmt(long ms) {
        if (ms < 0) ms = 0;
        long totalSec = ms / 1000;
        long h = totalSec / 3600;
        long m = (totalSec % 3600) / 60;
        long s = totalSec % 60;
        long milli = ms % 1000;
        if (h > 0) return String.format(Locale.US, "%d:%02d:%02d.%03d", h, m, s, milli);
        return String.format(Locale.US, "%02d:%02d.%03d", m, s, milli);
    }

    private static long parseTime(String text) {
        try {
            String[] parts = text.trim().split(":");
            double sec = 0;
            for (String p : parts) sec = sec * 60 + Double.parseDouble(p.trim());
            return (long) (sec * 1000);
        } catch (Exception e) {
            return -1;
        }
    }

    // ---------- surface ----------

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        surfaceReady = true;
        if (mp != null && prepared) {
            mp.setDisplay(holder);
            mp.seekTo((int) curMs, MediaPlayer.SEEK_CLOSEST);
        }
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        surfaceReady = false;
        if (mp != null) {
            try {
                mp.setDisplay(null);
            } catch (Exception ignored) {
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(tick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(tick);
        if (mp != null && prepared && mp.isPlaying()) {
            mp.pause();
            curMs = mp.getCurrentPosition();
            playBtn.setText("PLAY");
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        releasePlayer();
    }

    // ---------- cut ----------

    private void startCut() {
        if (srcUri == null || !prepared) {
            status.setText("Pehle video chuno.");
            return;
        }
        if (startMs < 0) {
            status.setText("START set nahi hua. Video me jaha se shuru karni hai wahan START yahan dabao.");
            return;
        }
        final long endFinal = endMs >= 0 ? endMs : durationMs;
        if (endFinal <= startMs) {
            status.setText("END, START ke baad hona chahiye.");
            return;
        }
        final String treeStr = getSharedPreferences("zlr", MODE_PRIVATE).getString("tree", null);
        if (treeStr == null) {
            status.setText("Pehle Settings me SD card folder chuno. Phone storage me save nahi karunga.");
            return;
        }
        stepBy(0);
        cutBtn.setEnabled(false);
        status.setText("Cut ho raha hai... 0%");
        final Uri src = srcUri;
        final long startUs = startMs * 1000L;
        final long endUs = endFinal * 1000L;
        new Thread(() -> {
            String msg;
            try {
                msg = cutFile(src, Uri.parse(treeStr), startUs, endUs);
            } catch (Exception ex) {
                msg = "Error: " + ex.getMessage();
            }
            final String result = msg;
            runOnUiThread(() -> {
                status.setText(result);
                cutBtn.setEnabled(true);
            });
        }, "zlr-cut").start();
    }

    private String cutFile(Uri src, Uri tree, long startUs, long endUs) throws Exception {
        MediaExtractor ex = new MediaExtractor();
        ParcelFileDescriptor inPfd = null;
        ParcelFileDescriptor outPfd = null;
        MediaMuxer mux = null;
        Uri outUri = null;
        boolean muxStarted = false;
        boolean ok = false;
        long written = 0;
        long bytes = 0;
        try {
            inPfd = getContentResolver().openFileDescriptor(src, "r");
            if (inPfd == null) throw new IOException("Video file khuli nahi");
            ex.setDataSource(inPfd.getFileDescriptor());

            Uri parent = DocumentsContract.buildDocumentUriUsingTree(
                    tree, DocumentsContract.getTreeDocumentId(tree));
            String name = "POV_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)
                    .format(new Date()) + ".mp4";
            outUri = DocumentsContract.createDocument(getContentResolver(), parent, "video/mp4", name);
            if (outUri == null) throw new IOException("SD card folder me file nahi ban payi");
            outPfd = getContentResolver().openFileDescriptor(outUri, "rw");
            if (outPfd == null) throw new IOException("Output file open nahi hui");
            mux = new MediaMuxer(outPfd.getFileDescriptor(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);

            int n = ex.getTrackCount();
            int[] map = new int[n];
            int added = 0;
            for (int i = 0; i < n; i++) {
                MediaFormat f = ex.getTrackFormat(i);
                String mime = f.getString(MediaFormat.KEY_MIME);
                if (mime != null && (mime.startsWith("video/") || mime.startsWith("audio/"))) {
                    ex.selectTrack(i);
                    map[i] = mux.addTrack(f);
                    added++;
                } else {
                    map[i] = -1;
                }
            }
            if (added == 0) throw new IOException("Video track nahi mila");
            mux.start();
            muxStarted = true;

            ex.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC);

            ByteBuffer buf = ByteBuffer.allocate(4 * 1024 * 1024);
            MediaCodec.BufferInfo bi = new MediaCodec.BufferInfo();
            long base = -1;
            int lastPct = -1;
            while (true) {
                int ti = ex.getSampleTrackIndex();
                if (ti < 0) break;
                long t = ex.getSampleTime();
                if (t > endUs) break;
                buf.clear();
                int size = ex.readSampleData(buf, 0);
                if (size < 0) break;
                if (base < 0) base = t;
                int flags = (ex.getSampleFlags() & MediaExtractor.SAMPLE_FLAG_SYNC) != 0
                        ? MediaCodec.BUFFER_FLAG_KEY_FRAME : 0;
                bi.set(0, size, Math.max(0, t - base), flags);
                if (map[ti] >= 0) {
                    mux.writeSampleData(map[ti], buf, bi);
                    written++;
                }
                int pct = (int) Math.min(100, (t - startUs) * 100 / Math.max(1, endUs - startUs));
                if (pct != lastPct && pct >= 0) {
                    lastPct = pct;
                    final int shown = pct;
                    runOnUiThread(() -> status.setText("Cut ho raha hai... " + shown + "%"));
                }
                ex.advance();
            }

            if (written > 0) {
                mux.stop();
                muxStarted = false;
                bytes = outPfd.getStatSize();
                ok = true;
            }
        } finally {
            try {
                if (mux != null && muxStarted) mux.stop();
            } catch (Exception ignored) {
            }
            try {
                if (mux != null) mux.release();
            } catch (Exception ignored) {
            }
            try {
                ex.release();
            } catch (Exception ignored) {
            }
            try {
                if (inPfd != null) inPfd.close();
            } catch (Exception ignored) {
            }
            try {
                if (outPfd != null) outPfd.close();
            } catch (Exception ignored) {
            }
            if (!ok && outUri != null) {
                try {
                    DocumentsContract.deleteDocument(getContentResolver(), outUri);
                } catch (Exception ignored) {
                }
            }
        }
        if (!ok) throw new IOException("Cut ke liye koi frame nahi mila");
        scanDoc(outUri);
        long mb = bytes / (1024 * 1024);
        return "Saved: " + describeDoc(outUri) + " (" + mb + " MB)";
    }

    private String describeDoc(Uri doc) {
        try {
            String id = DocumentsContract.getDocumentId(doc);
            int i = id.indexOf(':');
            String vol = id.substring(0, i);
            String rest = id.substring(i + 1);
            return (vol.equals("primary") ? "Internal/" : "SD card/") + rest;
        } catch (Exception e) {
            return "chuna hua folder";
        }
    }

    private void scanDoc(Uri doc) {
        try {
            String id = DocumentsContract.getDocumentId(doc);
            int i = id.indexOf(':');
            String vol = id.substring(0, i);
            String rest = id.substring(i + 1);
            String path = vol.equals("primary")
                    ? "/storage/emulated/0/" + rest
                    : "/storage/" + vol + "/" + rest;
            MediaScannerConnection.scanFile(this, new String[]{path}, new String[]{"video/mp4"}, null);
        } catch (Exception ignored) {
        }
    }
}
